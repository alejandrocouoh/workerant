package com.example.workerant;

import android.app.DownloadManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


import java.lang.ref.ReferenceQueue;

import entidades.ConexionBD;

public class MainActivity2_Registro extends AppCompatActivity {

    private EditText txv_correo;
    private EditText txv_celular;
    private EditText txv_password;
    private EditText txv_validarpass;
    String email, cel, pass, sentenciasql;
    ReferenceQueue request;
    private static final String URL="http://localhost:3010/workerants/instrucciones/insertar.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity2_registro);
        txv_correo = (EditText) findViewById(R.id.editTextTextEmailAddress_corr);
        txv_celular = (EditText) findViewById(R.id.editTextPhone_cel);
        txv_password = (EditText) findViewById(R.id.editTextTextPassword_pass);
        txv_validarpass = (EditText) findViewById(R.id.editTextTextPassword2);
        /*email = txv_correo.getText().toString();
        cel = txv_celular.toString().toString();
        pass = txv_password.toString().toString();*/
    }

    public void crearCuenta(View view){
        email = txv_correo.getText().toString();
        cel = txv_celular.getText().toString();
        pass = txv_password.getText().toString();


        /*sentenciasql = "INSER INTO cuentas (email, password, celular) VALUES ('"+email+"','"+pass+"','"+cel+"')";
        String sentenciasql = "insert into cuentas (email,password,celular) values ('prueba1','contraseña1','56845525')";
        sentenciasql = "INSER INTO cuentas (email) VALUES ('"+email+"')";
        sentenciasql = "INSER INTO cuentas (email,password,celular) VALUES (?,?,?)";

        conexion.mostrar();
        conexion.mostrar(sentenciasql);

        try{
            conexion = new ConexionBD();
            conexion.conectar();
            conexion.guardar(email,pass,cel);
            conexion.cerrarBD();
            //conexion.grabarRegistro(sentenciasql);
            //conexion.cerrarBD();
          if (conexion.guardar(sentenciasql)==1) {
                Toast.makeText(this, "Cuenta creada correctamente", Toast.LENGTH_LONG).show();
                conexion.cerrarBD();
            } else {
                Toast.makeText(this, "La cuenta no se pudo crear", Toast.LENGTH_LONG).show();
                conexion.cerrarBD();
            }
        } catch (Exception e){
            System.out.println(e);
        }*/
    }
}